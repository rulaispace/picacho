


export default function ReducerFactory(name) {

}