const reducerNames = {
    message: 'message',
    account: 'account',
    layout: 'layout',
    notification: 'notification',
    document: 'document',
    organization: 'organization',
    schedule: 'schedule',
    resource: 'resource',
    rule: 'rule',
    announcement: 'announcement',
    regulation: 'regulation',
}

export default reducerNames