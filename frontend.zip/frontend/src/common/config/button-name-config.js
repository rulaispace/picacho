const buttonNames = {
    close: 'button_close',
    save: 'button_save',
}

export default buttonNames